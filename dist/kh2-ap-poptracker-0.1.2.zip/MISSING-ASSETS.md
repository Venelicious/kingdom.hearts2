# Fehlende Item-Assets

176 von 293 Itemtypen besitzen ein zugeordnetes Icon: 40 aus Red-Buddha/KH2Tracker, 136 zusätzlich aus der lokalen KH2-Extraktion.
117 Itemtypen besitzen keine passende individuelle Grafik und verwenden weiterhin eigene Platzhalter.

Es wurden nur inhaltlich passende Icons zugeordnet. Welt-, Boss- und generische Kategorie-Icons zählen nicht als eigene Itemgrafik.

Die verbliebenen Fähigkeiten besitzen keine eigene Item-Bildzuordnung. Anti Form und Pureblood verweisen in der Spieltabelle auf Bild 0. Disney Castle Key, Unknown Disk, Lucky Emblem, Bounty sowie sechs Stat-/Slot-Upgrades verwenden AP- bzw. Dummy-Slots; deren ursprüngliche Grafiken wären irreführend.

## Progression (1)

- Disney Castle Key

## Forms (1)

- Anti Form

## Keyblade (1)

- Pureblood

## Usefull (7)

- Unknown Disk
- Max HP Up
- Max MP Up
- Drive Gauge Up
- Armor Slot Up
- Accessory Slot Up
- Item Slot Up

## SupportAbility (35)

- Scan
- Aerial Recovery
- Combo Master
- Combo Plus
- Air Combo Plus
- Combo Boost
- Air Combo Boost
- Reaction Boost
- Finishing Plus
- Negative Combo
- Berserk Charge
- Damage Drive
- Drive Boost
- Form Boost
- Summon Boost
- Experience Boost
- Draw
- Jackpot
- Lucky Lucky
- Drive Converter
- Fire Boost
- Blizzard Boost
- Thunder Boost
- Item Boost
- MP Rage
- MP Haste
- MP Hastera
- MP Hastega
- Defender
- Damage Control
- No Experience
- Light & Darkness
- Magic Lock-On
- Leaf Bracer
- Combination Boost

## ActionAbility (25)

- Guard
- Upper Slash
- Horizontal Slash
- Finishing Leap
- Retaliating Slash
- Slapshot
- Dodge Slash
- Flash Step
- Slide Dash
- Vicinity Break
- Guard Break
- Explosion
- Aerial Sweep
- Aerial Dive
- Aerial Spiral
- Aerial Finish
- Magnet Burst
- Counterguard
- Auto Valor
- Auto Wisdom
- Auto Limit
- Auto Master
- Auto Final
- Auto Summon
- Trinity Limit

## Wincon (2)

- Lucky Emblem
- Bounty

## DonaldAbility (21)

- Donald Fire
- Donald Blizzard
- Donald Thunder
- Donald Cure
- Donald Fantasia
- Donald Flare Force
- Donald MP Rage
- Donald Jackpot
- Donald Lucky Lucky
- Donald Fire Boost
- Donald Blizzard Boost
- Donald Thunder Boost
- Donald MP Haste
- Donald MP Hastera
- Donald MP Hastega
- Donald Auto Limit
- Donald Hyper Healing
- Donald Auto Healing
- Donald Item Boost
- Donald Damage Control
- Donald Draw

## GoofyAbility (24)

- Goofy Tornado
- Goofy Turbo
- Goofy Bash
- Tornado Fusion
- Teamwork
- Goofy Draw
- Goofy Jackpot
- Goofy Lucky Lucky
- Goofy Item Boost
- Goofy MP Rage
- Goofy Defender
- Goofy Damage Control
- Goofy Auto Limit
- Goofy Second Chance
- Goofy Once More
- Goofy Auto Change
- Goofy Hyper Healing
- Goofy Auto Healing
- Goofy MP Haste
- Goofy MP Hastera
- Goofy MP Hastega
- Goofy Protect
- Goofy Protera
- Goofy Protega
